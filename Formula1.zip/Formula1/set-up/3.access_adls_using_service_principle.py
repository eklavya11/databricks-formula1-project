# Databricks notebook source
# MAGIC %md
# MAGIC #### Access Azure Data Lake using service principle
# MAGIC 1. Register Azure AD application/Service Principle
# MAGIC 2. Generate a secret/password for application.
# MAGIC 3. Set spark config with App/Client Id, Directory/Tenant Id & Secret
# MAGIC 4. Assign Role 'Storage Blob Data Contributor' to the data lake.

# COMMAND ----------

client_id = "bedace2e-1d55-40b9-b7cc-d0be366dc155"
tenant_id = "4b8b5c11-7ec6-4711-b77e-ae2994d75f74"
client_secret = "hNu8Q~ViSYVlKQ9KhTmzzbMoJTeqDqONlhfhydly"

# COMMAND ----------

#service_credential = dbutils.secrets.get(scope="<secret-scope>",key="<service-credential-key>") - not needed

spark.conf.set("fs.azure.account.auth.type.formula1dl1811.dfs.core.windows.net", "OAuth")
spark.conf.set("fs.azure.account.oauth.provider.type.formula1dl1811.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set("fs.azure.account.oauth2.client.id.formula1dl1811.dfs.core.windows.net", client_id)
spark.conf.set("fs.azure.account.oauth2.client.secret.formula1dl1811.dfs.core.windows.net", client_secret)
spark.conf.set("fs.azure.account.oauth2.client.endpoint.formula1dl1811.dfs.core.windows.net", f"https://login.microsoftonline.com/{tenant_id}/oauth2/token")

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1dl1811.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv("abfss://demo@formula1dl1811.dfs.core.windows.net/circuits.csv"))

# COMMAND ----------

