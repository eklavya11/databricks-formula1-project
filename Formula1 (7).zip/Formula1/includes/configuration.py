# Databricks notebook source
raw_folder_path = '/mnt/formula1dl1811/raw'
processed_folder_path = '/mnt/formula1dl1811/processed'
presentation_folder_path = '/mnt/formula1dl1811/presentation'